package com.example.loanservice.domain;

public enum LoanType {
    PERSONAL,
    HOME,
    AUTO
}