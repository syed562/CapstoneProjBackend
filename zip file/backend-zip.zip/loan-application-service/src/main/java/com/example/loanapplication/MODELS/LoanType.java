package com.example.loanapplication.MODELS;

public enum LoanType {
    PERSONAL,
    HOME,
    AUTO,
    EDUCATIONAL,
    HOME_LOAN
}