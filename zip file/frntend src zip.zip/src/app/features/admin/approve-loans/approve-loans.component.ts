import { Component } from '@angular/core';

@Component({
  selector: 'app-approve-loans',
  standalone: true,
  imports: [],
  templateUrl: './approve-loans.component.html',
  styleUrl: './approve-loans.component.scss'
})
export class ApproveLoansComponent {

}
