export const environment = {
  production: true,
  apiUrl: 'http://localhost:8080/api',
  apiGatewayUrl: 'http://localhost:8080',
  tokenKey: 'jwt_token',
  userKey: 'current_user'
};
